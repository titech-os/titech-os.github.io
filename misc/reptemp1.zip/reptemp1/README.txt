1. Copy template1.tex.

   $ cp template1.tex report1.tex

2. Edit report1.tex with your favorite text editor.

3. Compile your LaTeX file using platex. If you use \ref or \cite in 
   your file, compilation should take place two (or more) times.

   $ platex report1
   $ platex report1

4. Generate a PDF file.

   $ dvipdfmx report1

5. Now you can view and print your document (report1.pdf) using
   Preview or Adobe (Acrobat) Reader.

