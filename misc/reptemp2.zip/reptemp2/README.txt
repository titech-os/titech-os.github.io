1. Copy template2.tex.

   $ cp template2.tex report2.tex

2. Edit report2.tex with your favorite text editor.

3. Compile your LaTeX file using platex. If you use \ref or \cite in 
   your file, compilation should take place two (or more) times.

   $ platex report2
   $ platex report2

4. Generate a PDF file.

   $ dvipdfmx report2

5. Now you can view and print your document (report2.pdf) using
   Preview or Adobe (Acrobat) Reader.

